module.exports = function () {
    var config = {
        app: 'MPE',
        dist: 'dist/',
        src: 'charte/src/',
        sass: {
            src: './charte/src/sass/',
            input: './charte/src/sass/style.scss',
            output: './../config/place/themes/portal/css/',
            watch: ['./charte/src/sass/**/*.sass', './charte/src/sass/**/*.scss']
        },
        js: {
            src: './charte/src/js/',
            input: './charte/src/js/**/*.js',
            lint: ['./charte/src/js/**/*.js', '!./charte/src/js/lib/**/*.js', '!./charte/src/js/extend/url.js'],
            output: './../config/place/themes/portal/js/',
            watch: ['./charte/src/js/**/*.js']
        },
        img: {
            src: './charte/src/img/',
            input: './charte/src/img/**/*.*',
            output: './../config/place/themes/portal/images/',
            watch: ['./charte/src/img/*']
        },
        tpl: {
            src: './charte/src/tpl/',
            input: './charte/src/tpl/*.html',
            output: './demo/pages/',
            watch: ['./charte/src/tpl/**/*']
        },
        lib: [


            {
                src: 'bower_components/jquery/dist/jquery.min.js',
                dist: '../config/place/themes/portal/lib/jquery/'
            },
            {
                src: 'bower_components/bootstrap/dist/js/bootstrap.min.js',
                dist: './../config/place/themes/portal/lib/bootstrap/'
            },
            {
                src: 'bower_components/select2/dist/js/select2.min.js',
                dist: './../config/place/themes/portal/lib/select2/'
            },
            {
                src: 'bower_components/select2/dist/js/select2.full.min.js',
                dist: './../config/place/themes/portal/lib/select2/'
            },
            {
                src: 'bower_components/select2/dist/css/select2.min.css',
                dist: './../config/place/themes/portal/lib/select2/'
            },
            {
                src: 'bower_components/font-awesome/fonts/*',
                dist: './../themes/fonts/'
            },
            {
                src: 'bower_components/moment/min/moment.min.js',
                dist: './../config/place/themes/portal/lib/moment/'
            },
            {
                src: 'bower_components/moment/locale/fr.js',
                dist: './../config/place/themes/portal/lib/moment/locale/'
            },
            {
                src: 'bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js',
                dist: './../config/place/themes/portal/lib/datetimepicker/'

            },
            {
                src: 'bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css',
                dist: './../config/place/themes/portal/lib/datetimepicker/'
            },
            {
                src: 'bower_components/jquery.scrollbar/jquery.scrollbar.min.js',
                dist: './../config/place/themes/portal/lib/jquery.scrollbar/'
            },
            {
                src: 'bower_components/bootstrap/dist/js/bootstrap.min.js',
                dist: './charte/src/js/lib/',
                basename: '01-bootstrap.min'
            },
            {
                src: 'bower_components/moment/min/moment.min.js',
                dist: './charte/src/js/lib/',
                basename: '02-moment.min'
            },
            {
                src: 'bower_components/moment/locale/fr.js',
                dist: './charte/src/js/lib/',
                basename: '03-fr'
            },
            {
                src: 'bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js',
                dist: './charte/src/js/lib/',
                basename: '04-datetimepicker.min'
            },
            {
                src: 'bower_components/bootstrap-confirmation2/bootstrap-confirmation.min.js',
                dist: './charte/src/js/lib/',
                basename: '05-bootstrap-confirmation.min'
            },
            {
                src: 'bower_components/jquery-validation/dist/jquery.validate.min.js',
                dist: './charte/src/js/lib/',
                basename: '06-jquery.validate.min'
            },
            {
                src: 'bower_components/jquery-validation/dist/additional-methods.min.js',
                dist: './charte/src/js/lib/',
                basename: '07-additional-methods.min'
            },
            {
                src: 'bower_components/jquery-validation/src/localization/messages_fr.js',
                dist: './charte/src/js/lib/',
                basename: '08-messages_fr'
            },
            {
                src: 'bower_components/remarkable-bootstrap-notify/dist/bootstrap-notify.min.js',
                dist: './charte/src/js/lib/',
                basename: '09-bootstrap-notify.min'
            },
            {
                src: 'bower_components/jquery.i18n/src/jquery.i18n.js',
                dist: './charte/src/js/lib/',
                basename: '10-jquery.i18n'
            }

        ]
    };
    return config;
}