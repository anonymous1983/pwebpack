var fs = require('fs'),
    gulp = require('gulp'),
    gulpif = require('gulp-if'),
    gulpLoadPlugins = require('gulp-load-plugins'),
    path = require('path'),
    argv = require('yargs').argv,
    sass = require('gulp-sass'),
    runSequence = require('run-sequence'),
    sourcemaps = require('gulp-sourcemaps'),
    rename = require('gulp-rename'),
    concat = require('gulp-concat'),
    browserSync = require('browser-sync'),
    superstatic = require('superstatic'),
    preprocess = require('gulp-preprocess'),
    extender = require('gulp-html-extend'),
    jshint = require('gulp-jshint'),
    stylish = require('jshint-stylish'),
    config = require('./gulp.config')(),
    notify = require('gulp-notify');


var $ = gulpLoadPlugins();

gulp.task('build-clean', function () {
    return gulp.src(config.dist, {read: false})
        .pipe($.clean());
});


/**
 * @example build single theme => gulp build-theme [--rsem || --mpe || --product] --theme Paris --watch
 * @example build single theme with environment => gulp build-theme [--rsem || --mpe || --product] --theme Paris  --env preprod --watch
 * * @example build single theme with environment => gulp build-theme [--rsem || --mpe || --product] --theme hm --subtheme arte  --env preprod --watch
 * @example build all themes => gulp build-theme [--rsem || --mpe || --product] --all
 */
gulp.task('build-theme', function () {

    // If application name not defined
    // Build theme not be working
    if (!config.app || config.app === '') {
        console.log('Application name is not defined !');
        return false;
    }


    //imgResult = gulp.src(config.img.input).pipe(gulp.dest(config.img.output));
    var _theme = (argv.theme === undefined) ? false : argv.theme,
        _subtheme = (argv.subtheme === undefined) ? false : argv.subtheme,
        sassCssResult = true,
        imgImagesResult = true,
        _pathBuild = '';


    const _ALL = (argv.all === undefined) ? false : argv.all;
    const _WATCH = (argv.watch === undefined) ? false : true;

    if (argv.theme === undefined || argv.theme === '') {
        // Get default theme if --theme not exist
        var _design_theme_config = JSON.parse(fs.readFileSync('./design/theme/config.json', "utf8"));
        _theme = _design_theme_config.theme[config.app]
    }

    var _getThemeConfig = function (_theme, _subtheme) {
        if (_subtheme) {
            return JSON.parse(fs.readFileSync('./design/theme/' + _theme + '/themes/' + _subtheme + '/config.json', "utf8"));
        } else {
            return JSON.parse(fs.readFileSync('./design/theme/' + _theme + '/config.json', "utf8"));
        }

    };

    const THEME_CONFIG = _getThemeConfig(_theme, _subtheme);

    // deprecated
    var _getPath = function (_theme) {
        console.log("Export to ./dist/" + _theme);
        return {
            css: './dist/' + _theme + '/themes/' + _subtheme + '/css/',
            img: './dist/' + _theme + '/themes/' + _subtheme + '/images/'
        };
    };

    var _getPathBuild = function (_theme, _subtheme) {

        if (!config.app || !THEME_CONFIG.build.path[config.app]) {
            (config.app) ?
                // If config.app state and path build of config app not fond
                console.log('Config [' + config.app + '] not fond !') :
                // If config.app not state
                console.log('Config not state !');
            return _getPath(_theme, _subtheme);

        } else {
            if (!THEME_CONFIG.build.path[config.app]['env'][_ENV]) {
                // If config environment not fond
                console.log('Environment [' + _ENV + '] not fond !');
                return _getPath(_theme, _subtheme);
            }
        }

        return {
            css: THEME_CONFIG.build.path[config.app]['env'][_ENV]['css'],
            img: THEME_CONFIG.build.path[config.app]['env'][_ENV]['img']
        };
    };

    var sassToCss = function (_theme, _subtheme) {
        var _src_style_scss = (!_subtheme) ? './design/theme/' + _theme + '/style.scss' : './design/theme/' + _theme + '/themes/' + _subtheme + '/style.scss';
        var _return = gulp.src(_src_style_scss)
            .pipe(sass().on('error', sass.logError))
            .pipe(concat('ng-style.css'))
            .pipe(gulp.dest(_getPathBuild(_theme, _subtheme).css))
            .pipe(
                sass({
                    outputStyle: 'compressed',
                    compress: true
                }).on('error', sass.logError))
            .pipe(rename({suffix: '.min'}))
            .pipe(gulp.dest(_getPathBuild(_theme, _subtheme).css))
            .pipe(notify('Sass compiled !'));

        //console.log('Sass to css '+ _theme);
        return _return;
    };

    var imgToImages = function (_theme, _subtheme) {
        var _src_img = (!_subtheme)
            ? './design/theme/' + _theme + '/img/' + _PRODUCT + '/' + _ENV + '/**/*.*'
            : './design/theme/' + _theme + '/themes/' + _subtheme + '/img/' + _PRODUCT + '/' + _ENV + '/**/*.*';
        var _return = gulp.src(_src_img).pipe(gulp.dest(_getPathBuild(_theme, _subtheme).img));
        return _return;
    };

    if (_theme) {
        console.log('Export theme : ' + _theme);
        notify('Export theme : ' + _theme);
        _pathBuild = _getPathBuild(_theme);
        console.log("Export to " + _pathBuild.css);
        notify('Export to ' + _pathBuild.css);

        try {
            // Query the entry
            var dirTheme = (!_subtheme) ? fs.lstatSync('./design/theme/' + _theme) : fs.lstatSync('./design/theme/' + _theme + '/themes/' + _subtheme);

            // Is it a directory?
            if (dirTheme.isDirectory()) {
                sassCssResult = sassToCss(_theme, _subtheme);
                imgImagesResult = imgToImages(_theme, _subtheme);

                if (_WATCH) {
                    gulp.watch(
                        [config.sass.watch, config.img.watch, './design/theme/' + _theme + '/**/*.sass', './design/theme/' + _theme + '/**/*.scss', './design/theme/' + _theme + '/img/**/*.*'],
                        ['build-theme']);
                }
            }
        }
        catch (e) {
            console.log('Not found theme dir !');
        }

    } else {
        // For build All theme
        // ToDo

        if (_ALL) {
            console.log('Build all theme');
            console.log(_ALL);

            function getDirectories(srcpath) {
                /*return fs.readdirSync(srcpath)
                 .filter(file => fs.statSync(path.join(srcpath, file)).isDirectory())*/
            }

            getDirectories('./design/theme/').forEach(function (theme, index, array) {
                console.log((index + 1) + ' => ' + theme);
                sassToCss(theme);
                imgToImages(theme);
            });
        }

    }


    return sassCssResult;
});

gulp.task('build', function (callback) {
    runSequence('build-clean',
        ['build-theme'],
        callback);
});

gulp.task('watch.build', ['build-theme'], function () {
    gulp.watch([config.sass.watch, config.img.watch], ['build-theme']);
});

gulp.task('watch', ['watch.build']);

gulp.task('default', ['build']);